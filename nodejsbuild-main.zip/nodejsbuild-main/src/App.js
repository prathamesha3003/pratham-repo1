import React from "react";
import './App.css'; // Importing the CSS file for styles

const App = () => {
  return (
    <div className="container">
      <h1 className="text">Welcome to the cloud automation...</h1>
    </div>
  );
};

export default App;
